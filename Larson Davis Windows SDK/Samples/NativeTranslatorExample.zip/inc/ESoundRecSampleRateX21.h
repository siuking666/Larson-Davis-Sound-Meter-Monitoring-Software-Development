/**************************************************************************//**
 * @file ESoundRecSampleRateX21.h
 * @brief Native Wrapper for Managed type SoundRecSampleRateX21.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _ESOUND_REC_SAMPLE_RATE_X21_H
#define _ESOUND_REC_SAMPLE_RATE_X21_H
namespace LarsonDavis
{
	namespace Native
	{
		enum class ESoundRecSampleRateX21
		{
			SR_SAMPLE_RATE_48KHZ = 0,
			SR_SAMPLE_RATE_24KHZ = 1,
			SR_SAMPLE_RATE_16KHZ = 2,
			SR_SAMPLE_RATE_8KHZ = 3,
		};
	}
}
#endif // _ESOUND_REC_SAMPLE_RATE_X21_H
