/**************************************************************************//**
 * @file SOverallDataFileSpartan_t.h
 * @brief Native Wrapper for Managed type OverallDataFileSpartan_t.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _SOVERALL_DATA_FILE_SPARTAN_T_H
#define _SOVERALL_DATA_FILE_SPARTAN_T_H
#include <ISupportByteArrayConversion.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ISupportByteArrayConversion;
		struct LDAPI SFileInfoHeaderSpartan_t;
		struct LDAPI SBlockHeaderSpartan_t;
		struct LDAPI SDeviceInfoSpartan_t;
		struct LDAPI SBlockFooterSpartan_t;
		struct LDAPI SSysSettingsSpartan_t;
		struct LDAPI SMeasSettingsSpartan_t;
		struct LDAPI SCustomReportSettingsSpartan_t;
		struct LDAPI SOverallDataSpartan_t;
		struct LDAPI SObaData48Bins_t;
		struct LDAPI SExcdDataSpartan_t;
		struct LDAPI SLnDataSpartan_t;
		struct LDAPI SDailyNoise_t;
		class LDAPI Array_float;
		struct LDAPI SPrePostCalSpartan_v2_t;
		struct LDAPI SPTBInfo_t;
		struct LDAPI SLnStatConfig_t;

		struct LDAPI SOverallDataFileSpartan_t : public virtual ISupportByteArrayConversion
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			SOverallDataFileSpartan_t(const SOverallDataFileSpartan_t& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~SOverallDataFileSpartan_t(void);
			SOverallDataFileSpartan_t(void);
			std::shared_ptr<SFileInfoHeaderSpartan_t> fileHeader(void);
			void fileHeader(std::shared_ptr<SFileInfoHeaderSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> deviceInfoHeader(void);
			void deviceInfoHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SDeviceInfoSpartan_t> deviceInfo(void);
			void deviceInfo(std::shared_ptr<SDeviceInfoSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> deviceInfoFooter(void);
			void deviceInfoFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> systemSettingsHeader(void);
			void systemSettingsHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SSysSettingsSpartan_t> systemSettings(void);
			void systemSettings(std::shared_ptr<SSysSettingsSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> systemSettingsFooter(void);
			void systemSettingsFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> measurementSettingsHeader(void);
			void measurementSettingsHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SMeasSettingsSpartan_t> measurementSettings(void);
			void measurementSettings(std::shared_ptr<SMeasSettingsSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> measurementSettingsFooter(void);
			void measurementSettingsFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> customReportSettingsHeader(void);
			void customReportSettingsHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SCustomReportSettingsSpartan_t> customReportSettings(void);
			void customReportSettings(std::shared_ptr<SCustomReportSettingsSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> customReportSettingsFooter(void);
			void customReportSettingsFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> overallDataHeader(void);
			void overallDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SOverallDataSpartan_t> overallData(void);
			void overallData(std::shared_ptr<SOverallDataSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> overallDataFooter(void);
			void overallDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> obaDataHeader(void);
			void obaDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SObaData48Bins_t> obaData(void);
			void obaData(std::shared_ptr<SObaData48Bins_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> obaDataFooter(void);
			void obaDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> excdDataHeader(void);
			void excdDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SExcdDataSpartan_t> excdData(void);
			void excdData(std::shared_ptr<SExcdDataSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> excdDataFooter(void);
			void excdDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> lnDataHeader(void);
			void lnDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SLnDataSpartan_t> lnData(void);
			void lnData(std::shared_ptr<SLnDataSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> lnDataFooter(void);
			void lnDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> dailyDataHeader(void);
			void dailyDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SDailyNoise_t> dailyData(void);
			void dailyData(std::shared_ptr<SDailyNoise_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> dailyDataFooter(void);
			void dailyDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> profileDataHeader(void);
			void profileDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<Array_float> profileData(void);
			void profileData(std::shared_ptr<Array_float> value);
			std::shared_ptr<SBlockFooterSpartan_t> profileDataFooter(void);
			void profileDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> rangeDataHeader(void);
			void rangeDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<Array_float> rangeData(void);
			void rangeData(std::shared_ptr<Array_float> value);
			std::shared_ptr<SBlockFooterSpartan_t> rangeDataFooter(void);
			void rangeDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> preCalDataHeader(void);
			void preCalDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SPrePostCalSpartan_v2_t> preCalData(void);
			void preCalData(std::shared_ptr<SPrePostCalSpartan_v2_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> preCalDataFooter(void);
			void preCalDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> deviceDescHeader(void);
			void deviceDescHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> deviceDescFooter(void);
			void deviceDescFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> postCalDataHeader(void);
			void postCalDataHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SPrePostCalSpartan_v2_t> postCalData(void);
			void postCalData(std::shared_ptr<SPrePostCalSpartan_v2_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> postCalDataFooter(void);
			void postCalDataFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> agencyApprovalHeader(void);
			void agencyApprovalHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SPTBInfo_t> agencyApprovalData(void);
			void agencyApprovalData(std::shared_ptr<SPTBInfo_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> agencyApprovalFooter(void);
			void agencyApprovalFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
			std::shared_ptr<SBlockHeaderSpartan_t> lnConfigHeader(void);
			void lnConfigHeader(std::shared_ptr<SBlockHeaderSpartan_t> value);
			std::shared_ptr<SLnStatConfig_t> lnConfig(void);
			void lnConfig(std::shared_ptr<SLnStatConfig_t> value);
			std::shared_ptr<SBlockFooterSpartan_t> lnConfigFooter(void);
			void lnConfigFooter(std::shared_ptr<SBlockFooterSpartan_t> value);
#ifdef MAKEDLL
		public: // This is for internal use
			SOverallDataFileSpartan_t(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _SOVERALL_DATA_FILE_SPARTAN_T_H
