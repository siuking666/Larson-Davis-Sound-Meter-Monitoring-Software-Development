/**************************************************************************//**
 * @file EExchangeRateId_t.h
 * @brief Native Wrapper for Managed type ExchangeRateId_t.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _EEXCHANGE_RATE_ID_T_H
#define _EEXCHANGE_RATE_ID_T_H
namespace LarsonDavis
{
	namespace Native
	{
		enum class EExchangeRateId_t
		{
			offset = 3,
			dose_ex_rate_3dB = 3,
			dose_ex_rate_4dB = 4,
			dose_ex_rate_5dB = 5,
			dose_ex_rate_6dB = 6,
		};
	}
}
#endif // _EEXCHANGE_RATE_ID_T_H
