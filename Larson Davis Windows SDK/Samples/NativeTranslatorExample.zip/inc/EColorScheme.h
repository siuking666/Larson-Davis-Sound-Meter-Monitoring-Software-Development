/**************************************************************************//**
 * @file EColorScheme.h
 * @brief Native Wrapper for Managed type ColorScheme.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _ECOLOR_SCHEME_H
#define _ECOLOR_SCHEME_H
namespace LarsonDavis
{
	namespace Native
	{
		enum class EColorScheme
		{
			Dark = 0,
			Light = 1,
		};
	}
}
#endif // _ECOLOR_SCHEME_H
