/**************************************************************************//**
 * @file LDRecordBase_CMetaDataRecord.h
 * @brief Native Wrapper for Managed type LDRecordBase<LarsonDavis::SDK::LDCommonStd::MetaData::MetaDataRecord^>.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _LDRECORD_BASE_CMETA_DATA_RECORD_H
#define _LDRECORD_BASE_CMETA_DATA_RECORD_H
#include <CReactiveObservableBase.h>
#include <ILDRecordWithMetaRecord_CMetaDataRecord.h>
#include <CMetaDataRecord.h>
#include <EEditBandAction.h>
#include <EBlockTag.h>
#include <EParseError.h>
#include <EMeterType.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI CReactiveObservableBase;
		class LDAPI ILDRecordWithMetaRecord_CMetaDataRecord;
		class LDAPI CCalibration;
		class LDAPI CMetaDataRecord;
		class LDAPI IGeneralMetaBlock;
		class LDAPI CGeneralInfo;
		class LDAPI IEditBandMetaBlock;
		class LDAPI SortedList_int32_t_CEditBandInfo;
		class LDAPI CEditBandInfo;
		class LDAPI IComparer_int32_t;
		class LDAPI IDictionary_int32_t_CEditBandInfo;
		class LDAPI IList_int32_t;
		class LDAPI IList_CEditBandInfo;
		class LDAPI IChartMetaBlock;
		class LDAPI IList_CChartInfo;
		class LDAPI CChartInfo;
		class LDAPI ICommentMetaBlock;
		class LDAPI List_CMarkerInfo;
		class LDAPI CMarkerInfo;
		class LDAPI IComparer_CMarkerInfo;
		class LDAPI Array_CMarkerInfo;
		class LDAPI IRt60DecayMetaBlock;
		class LDAPI List_CRt60DecayInfo;
		class LDAPI CRt60DecayInfo;
		class LDAPI IComparer_CRt60DecayInfo;
		class LDAPI Array_CRt60DecayInfo;
		class LDAPI CSoundRecordMetaBlock;
		class LDAPI IList_CSoundRecordInfo;
		class LDAPI CSoundRecordInfo;
		class LDAPI CManifestMetaBlock;
		class LDAPI IList_CMetaBlockInfo;
		class LDAPI CMetaBlockInfo;
		class LDAPI Array_float;
		struct LDAPI SPTBInfo_t;
		class LDAPI IList_StringWrapper;

		class LDAPI LDRecordBase_CMetaDataRecord : public CReactiveObservableBase, public virtual ILDRecordWithMetaRecord_CMetaDataRecord
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			LDRecordBase_CMetaDataRecord(const LDRecordBase_CMetaDataRecord& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~LDRecordBase_CMetaDataRecord(void);
			int64_t GetTimeHistoryTimestamp(int32_t entryNum);
			StringWrapper GetMetricType(void);
			float GetMetricValue(void);
			StringWrapper GetDesiredMetricSetting(void);
			StringWrapper GetFullModelString(void);
			void SetPreampName(void);
			StringWrapper GetMicrophoneInfo(void);
			std::shared_ptr<CCalibration> GetPreCalData(bool skipSessionLog = false);
			StringWrapper DataFileName(void);
			void DataFileName(StringWrapper value);
			StringWrapper Model(void);
			void Model(StringWrapper value);
			StringWrapper Manufacturer(void);
			void Manufacturer(StringWrapper value);
			StringWrapper SerialNumber(void);
			void SerialNumber(StringWrapper value);
			StringWrapper FwVersion(void);
			void FwVersion(StringWrapper value);
			StringWrapper HwVersion(void);
			void HwVersion(StringWrapper value);
			std::shared_ptr<CMetaDataRecord> MetaRec(void);
			void MetaRec(std::shared_ptr<CMetaDataRecord> value);
			StringWrapper User(void);
			void User(StringWrapper value);
			StringWrapper Location(void);
			void Location(StringWrapper value);
			StringWrapper JobDescription(void);
			void JobDescription(StringWrapper value);
			StringWrapper GenInfoNote(void);
			void GenInfoNote(StringWrapper value);
			StringWrapper FilePath(void);
			void FilePath(StringWrapper value);
			int64_t FileSize(void);
			void FileSize(int64_t value);
			StringWrapper Metric1Type(void);
			void Metric1Type(StringWrapper value);
			float Metric1Level(void);
			void Metric1Level(float value);
			uint32_t StartTimeSeconds(void);
			void StartTimeSeconds(uint32_t value);
			uint32_t RunTimeSeconds(void);
			void RunTimeSeconds(uint32_t value);
			int32_t NumEvents(void);
			void NumEvents(int32_t value);
			int32_t NumOverloads(void);
			void NumOverloads(int32_t value);
			int32_t UserRow(void);
			void UserRow(int32_t value);
			int32_t LocationRow(void);
			void LocationRow(int32_t value);
			int32_t JobDescriptionRow(void);
			void JobDescriptionRow(int32_t value);
			int32_t NoteRow(void);
			void NoteRow(int32_t value);
			int32_t IssueRow(void);
			void IssueRow(int32_t value);
			bool ParseErrorOccurred(void);
			EParseError ParseErrors(void);
			void ParseErrors(EParseError value);
			int64_t LastModifiedTime(void);
			void LastModifiedTime(int64_t value);
			std::shared_ptr<Array_float> NFUnderRangeLimitsRms(void);
			void NFUnderRangeLimitsRms(std::shared_ptr<Array_float> value);
			std::shared_ptr<Array_float> NFUnderRangeLimitsPeak(void);
			void NFUnderRangeLimitsPeak(std::shared_ptr<Array_float> value);
			std::shared_ptr<Array_float> NFUnderNoiseFloor(void);
			void NFUnderNoiseFloor(std::shared_ptr<Array_float> value);
			std::shared_ptr<Array_float> UnderRangeLimitsOctave(void);
			void UnderRangeLimitsOctave(std::shared_ptr<Array_float> value);
			std::shared_ptr<Array_float> UnderRangeLimitsThirdOctave(void);
			void UnderRangeLimitsThirdOctave(std::shared_ptr<Array_float> value);
			std::shared_ptr<Array_float> NoiseFloorOctave(void);
			void NoiseFloorOctave(std::shared_ptr<Array_float> value);
			std::shared_ptr<Array_float> NoiseFloorThirdOctave(void);
			void NoiseFloorThirdOctave(std::shared_ptr<Array_float> value);
			float NFOverload(void);
			void NFOverload(float value);
			bool TmsEnabled(void);
			EMeterType MeterType(void);
			void MeterType(EMeterType value);
			uint32_t PurOptions(void);
			void PurOptions(uint32_t value);
			std::shared_ptr<SPTBInfo_t> PTBInfo(void);
			void PTBInfo(std::shared_ptr<SPTBInfo_t> value);
			StringWrapper PreampName(void);
			void PreampName(StringWrapper value);
			uint32_t SequenceId(void);
			void SequenceId(uint32_t value);
			StringWrapper UniqueFileId(void);
			void UniqueFileId(StringWrapper value);
			int32_t SkipThreshold(void);
			void SkipThreshold(int32_t value);
			std::shared_ptr<IList_StringWrapper> Issues(void);
#ifdef MAKEDLL
		public: // This is for internal use
			LDRecordBase_CMetaDataRecord(){};
			LDRecordBase_CMetaDataRecord(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _LDRECORD_BASE_CMETA_DATA_RECORD_H
