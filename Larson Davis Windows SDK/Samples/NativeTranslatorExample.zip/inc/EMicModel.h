/**************************************************************************//**
 * @file EMicModel.h
 * @brief Native Wrapper for Managed type MicModel.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _EMIC_MODEL_H
#define _EMIC_MODEL_H
namespace LarsonDavis
{
	namespace Native
	{
		enum class EMicModel
		{
			MIC_377B02 = 0,
			MIC_375A04 = 1,
			MIC_OTHER = 2,
			MIC_377A12 = 3,
		};
	}
}
#endif // _EMIC_MODEL_H
