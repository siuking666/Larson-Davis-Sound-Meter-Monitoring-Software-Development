/**************************************************************************//**
 * @file SSysSettingsSpartan_t.h
 * @brief Native Wrapper for Managed type SysSettingsSpartan_t.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _SSYS_SETTINGS_SPARTAN_T_H
#define _SSYS_SETTINGS_SPARTAN_T_H
#include <ISupportByteArrayConversion.h>
#include <EDateFormatSpartan_t.h>
#include <ELanguage.h>
#include <EDecimalFormat.h>
#include <EDosAutoOff_t.h>
#include <EPropOnOff_t.h>
#include <EMicModel.h>
#include <EColorScheme.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ISupportByteArrayConversion;

		struct LDAPI SSysSettingsSpartan_t : public virtual ISupportByteArrayConversion
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			SSysSettingsSpartan_t(const SSysSettingsSpartan_t& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~SSysSettingsSpartan_t(void);
			SSysSettingsSpartan_t(void);
			StringWrapper UserDefinedName(void);
			void UserDefinedName(StringWrapper value);
			EDateFormatSpartan_t DateFormat(void);
			void DateFormat(EDateFormatSpartan_t value);
			float NoiseLevel(void);
			void NoiseLevel(float value);
			float dBReference(void);
			void dBReference(float value);
			ELanguage Language(void);
			void Language(ELanguage value);
			EDecimalFormat DecimalChar(void);
			void DecimalChar(EDecimalFormat value);
			EDosAutoOff_t AutoOffTime(void);
			void AutoOffTime(EDosAutoOff_t value);
			StringWrapper BLEAuthKey(void);
			void BLEAuthKey(StringWrapper value);
			float CalLevel(void);
			void CalLevel(float value);
			StringWrapper AdminPass(void);
			void AdminPass(StringWrapper value);
			int32_t AdminFlags(void);
			void AdminFlags(int32_t value);
			EPropOnOff_t AutoStoreEnable(void);
			void AutoStoreEnable(EPropOnOff_t value);
			EPropOnOff_t ModemEnable(void);
			void ModemEnable(EPropOnOff_t value);
			int32_t ModemPeriod(void);
			void ModemPeriod(int32_t value);
			StringWrapper ModemHost(void);
			void ModemHost(StringWrapper value);
			int32_t ModemPort(void);
			void ModemPort(int32_t value);
			StringWrapper ModemAPN(void);
			void ModemAPN(StringWrapper value);
			int32_t Backlight(void);
			void Backlight(int32_t value);
			int32_t CorrSelect(void);
			void CorrSelect(int32_t value);
			EMicModel MicSelect(void);
			void MicSelect(EMicModel value);
			StringWrapper PreampSerial(void);
			void PreampSerial(StringWrapper value);
			StringWrapper MicSerial(void);
			void MicSerial(StringWrapper value);
			StringWrapper MicModel(void);
			void MicModel(StringWrapper value);
			float MicSensitivity(void);
			void MicSensitivity(float value);
			EPropOnOff_t DCOutEnable(void);
			void DCOutEnable(EPropOnOff_t value);
			int32_t DACOutAdjust(void);
			void DACOutAdjust(int32_t value);
			float ExtShutdownVolt(void);
			void ExtShutdownVolt(float value);
			StringWrapper CustomMicName(void);
			void CustomMicName(StringWrapper value);
			float CustomMicSensitivity(void);
			void CustomMicSensitivity(float value);
			float CustomMicNoiseLevel(void);
			void CustomMicNoiseLevel(float value);
			EColorScheme ColorScheme(void);
			void ColorScheme(EColorScheme value);
			EPropOnOff_t BleControl(void);
			void BleControl(EPropOnOff_t value);
			EPropOnOff_t AirplaneMode(void);
			void AirplaneMode(EPropOnOff_t value);
#ifdef MAKEDLL
		public: // This is for internal use
			SSysSettingsSpartan_t(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _SSYS_SETTINGS_SPARTAN_T_H
