/**************************************************************************//**
 * @file SDeviceInfoSpartan_t.h
 * @brief Native Wrapper for Managed type DeviceInfoSpartan_t.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _SDEVICE_INFO_SPARTAN_T_H
#define _SDEVICE_INFO_SPARTAN_T_H
#include <ISupportByteArrayConversion.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ISupportByteArrayConversion;
		class LDAPI Array_uint32_t;

		struct LDAPI SDeviceInfoSpartan_t : public virtual ISupportByteArrayConversion
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			SDeviceInfoSpartan_t(const SDeviceInfoSpartan_t& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~SDeviceInfoSpartan_t(void);
			SDeviceInfoSpartan_t(void);
			StringWrapper SerialNumber(void);
			void SerialNumber(StringWrapper value);
			StringWrapper Model(void);
			void Model(StringWrapper value);
			StringWrapper HWVersion(void);
			void HWVersion(StringWrapper value);
			StringWrapper FWVersion(void);
			void FWVersion(StringWrapper value);
			float Sensitivity(void);
			void Sensitivity(float value);
			StringWrapper Manufacturer(void);
			void Manufacturer(StringWrapper value);
			uint32_t FWDate(void);
			void FWDate(uint32_t value);
			std::shared_ptr<Array_uint32_t> Options(void);
			void Options(std::shared_ptr<Array_uint32_t> value);
			uint32_t SequenceId(void);
			void SequenceId(uint32_t value);
#ifdef MAKEDLL
		public: // This is for internal use
			SDeviceInfoSpartan_t(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _SDEVICE_INFO_SPARTAN_T_H
