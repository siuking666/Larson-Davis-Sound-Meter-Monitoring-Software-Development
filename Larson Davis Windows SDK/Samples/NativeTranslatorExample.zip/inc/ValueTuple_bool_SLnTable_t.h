/**************************************************************************//**
 * @file ValueTuple_bool_SLnTable_t.h
 * @brief Native Wrapper for Managed type ValueTuple<System::Boolean, LarsonDavis::SDK::LDCommonStd::Legacy::LnTable_t>.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _VALUE_TUPLE_BOOL_SLN_TABLE_T_H
#define _VALUE_TUPLE_BOOL_SLN_TABLE_T_H
#include <ITuple.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ITuple;
		struct LDAPI SLnTable_t;

		struct LDAPI ValueTuple_bool_SLnTable_t : public virtual ITuple
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			ValueTuple_bool_SLnTable_t(const ValueTuple_bool_SLnTable_t& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~ValueTuple_bool_SLnTable_t(void);
			ValueTuple_bool_SLnTable_t(void);
			int32_t CompareTo(std::shared_ptr<ValueTuple_bool_SLnTable_t> other);
			ValueTuple_bool_SLnTable_t(bool item1, std::shared_ptr<SLnTable_t> item2);
			bool Item1(void);
			void Item1(bool value);
			std::shared_ptr<SLnTable_t> Item2(void);
			void Item2(std::shared_ptr<SLnTable_t> value);
#ifdef MAKEDLL
		public: // This is for internal use
			ValueTuple_bool_SLnTable_t(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _VALUE_TUPLE_BOOL_SLN_TABLE_T_H
