/**************************************************************************//**
 * @file SLnStatConfig_t.h
 * @brief Native Wrapper for Managed type LnStatConfig_t.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _SLN_STAT_CONFIG_T_H
#define _SLN_STAT_CONFIG_T_H
#include <ISupportByteArrayConversion.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ISupportByteArrayConversion;

		struct LDAPI SLnStatConfig_t : public virtual ISupportByteArrayConversion
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			SLnStatConfig_t(const SLnStatConfig_t& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~SLnStatConfig_t(void);
			SLnStatConfig_t(void);
			float lowerdB(void);
			void lowerdB(float value);
			float upperdB(void);
			void upperdB(float value);
			int32_t numBins(void);
			void numBins(int32_t value);
			int32_t binsPerdB(void);
			void binsPerdB(int32_t value);
			float binResolutiondB(void);
			void binResolutiondB(float value);
			int32_t numSpectra(void);
			void numSpectra(int32_t value);
#ifdef MAKEDLL
		public: // This is for internal use
			SLnStatConfig_t(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _SLN_STAT_CONFIG_T_H
