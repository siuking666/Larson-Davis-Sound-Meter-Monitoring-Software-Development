/**************************************************************************//**
 * @file SCustomReportSettingsSpartan_t.h
 * @brief Native Wrapper for Managed type CustomReportSettingsSpartan_t.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _SCUSTOM_REPORT_SETTINGS_SPARTAN_T_H
#define _SCUSTOM_REPORT_SETTINGS_SPARTAN_T_H
#include <ISupportByteArrayConversion.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ISupportByteArrayConversion;

		struct LDAPI SCustomReportSettingsSpartan_t : public virtual ISupportByteArrayConversion
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			SCustomReportSettingsSpartan_t(const SCustomReportSettingsSpartan_t& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~SCustomReportSettingsSpartan_t(void);
			SCustomReportSettingsSpartan_t(void);
			uint32_t CustomReportFlags0(void);
			void CustomReportFlags0(uint32_t value);
			uint32_t CustomReportFlags1(void);
			void CustomReportFlags1(uint32_t value);
			uint32_t CustomReportFlags2(void);
			void CustomReportFlags2(uint32_t value);
			uint32_t CustomReportFlags3(void);
			void CustomReportFlags3(uint32_t value);
			uint32_t CustomReportFlags4(void);
			void CustomReportFlags4(uint32_t value);
			uint32_t CustomReportFlags5(void);
			void CustomReportFlags5(uint32_t value);
			uint32_t CustomReportFlags6(void);
			void CustomReportFlags6(uint32_t value);
			uint32_t CustomReportFlags7(void);
			void CustomReportFlags7(uint32_t value);
#ifdef MAKEDLL
		public: // This is for internal use
			SCustomReportSettingsSpartan_t(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _SCUSTOM_REPORT_SETTINGS_SPARTAN_T_H
