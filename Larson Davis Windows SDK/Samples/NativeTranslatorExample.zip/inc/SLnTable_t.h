/**************************************************************************//**
 * @file SLnTable_t.h
 * @brief Native Wrapper for Managed type LnTable_t.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _SLN_TABLE_T_H
#define _SLN_TABLE_T_H
#include <ISupportByteArrayConversion.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ISupportByteArrayConversion;
		class LDAPI Array_int32_t;

		struct LDAPI SLnTable_t : public virtual ISupportByteArrayConversion
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			SLnTable_t(const SLnTable_t& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~SLnTable_t(void);
			SLnTable_t(void);
			int32_t samples(void);
			void samples(int32_t value);
			std::shared_ptr<Array_int32_t> table(void);
			void table(std::shared_ptr<Array_int32_t> value);
#ifdef MAKEDLL
		public: // This is for internal use
			SLnTable_t(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _SLN_TABLE_T_H
