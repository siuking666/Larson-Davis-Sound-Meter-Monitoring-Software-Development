/**************************************************************************//**
 * @file CLnStatConfig.h
 * @brief Native Wrapper for Managed type LnStatConfig.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _CLN_STAT_CONFIG_H
#define _CLN_STAT_CONFIG_H
#include <CReactiveObject.h>
#include <ILnStatConfig.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI CReactiveObject;
		class LDAPI ILnStatConfig;
		struct LDAPI ValueTuple_float_float;
		struct LDAPI SLnTable_t;
		struct LDAPI ValueTuple_bool_SLnTable_t;
		class LDAPI ILDRecord;
		struct LDAPI SLnStatConfig_t;

		class LDAPI CLnStatConfig : public CReactiveObject, public virtual ILnStatConfig
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			CLnStatConfig(const CLnStatConfig& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~CLnStatConfig(void);
			float CalculateUpperdB(int32_t numBins, bool hasOverUnder = true);
			std::shared_ptr<ValueTuple_float_float> GetRange(void);
			StringWrapper GetFormattedLevelWithinRange(float level);
			std::shared_ptr<ValueTuple_bool_SLnTable_t> UpdateLnTableBin(std::shared_ptr<SLnTable_t> lnTable, int32_t bin);
			std::shared_ptr<SLnTable_t> ResetLnTable(std::shared_ptr<SLnTable_t> lnTable);
			CLnStatConfig(void);
			CLnStatConfig(std::shared_ptr<ILDRecord> record);
			CLnStatConfig(std::shared_ptr<SLnStatConfig_t> lnConfig);
			CLnStatConfig(int32_t binsPerdB, float lowerdB, float upperdB);
			int32_t BinsPerdB(void);
			void BinsPerdB(int32_t value);
			float BinResolutiondB(void);
			void BinResolutiondB(float value);
			float LowerdB(void);
			void LowerdB(float value);
			float UpperdB(void);
			void UpperdB(float value);
			float SpandB(void);
			void SpandB(float value);
			int32_t NumStatBins(void);
			void NumStatBins(int32_t value);
			int32_t NumLnStatBins(void);
			void NumLnStatBins(int32_t value);
			int32_t UnderBin(void);
			void UnderBin(int32_t value);
			int32_t OverBin(void);
			void OverBin(int32_t value);
			float MinPercent(void);
			void MinPercent(float value);
			float MaxPercent(void);
			void MaxPercent(float value);
			int32_t NumSpectra(void);
			void NumSpectra(int32_t value);
#ifdef MAKEDLL
		public: // This is for internal use
			CLnStatConfig(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _CLN_STAT_CONFIG_H
