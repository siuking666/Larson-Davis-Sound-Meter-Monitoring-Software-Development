/**************************************************************************//**
 * @file ListWithDefault_StringWrapper.h
 * @brief Native Wrapper for Managed type ListWithDefault<System::String^>.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _LIST_WITH_DEFAULT_STRING_WRAPPER_H
#define _LIST_WITH_DEFAULT_STRING_WRAPPER_H
#include <IList_StringWrapper.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI IList_StringWrapper;
		class LDAPI Array_StringWrapper;

		class LDAPI ListWithDefault_StringWrapper : public virtual IList_StringWrapper
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			ListWithDefault_StringWrapper(const ListWithDefault_StringWrapper& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~ListWithDefault_StringWrapper(void);
			void Add(StringWrapper item);
			void Clear(void);
			bool Contains(StringWrapper item);
			void CopyTo(std::shared_ptr<Array_StringWrapper> array, int32_t arrayIndex);
			int32_t IndexOf(StringWrapper item);
			void Insert(int32_t index, StringWrapper item);
			bool Remove(StringWrapper item);
			void RemoveAt(int32_t index);
			ListWithDefault_StringWrapper(StringWrapper defaultValue);
			StringWrapper Item(int32_t index);
			void Item(int32_t index, StringWrapper value);
			int32_t Count(void);
			bool IsReadOnly(void);
#ifdef MAKEDLL
		public: // This is for internal use
			ListWithDefault_StringWrapper(){};
			ListWithDefault_StringWrapper(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _LIST_WITH_DEFAULT_STRING_WRAPPER_H
