/**************************************************************************//**
 * @file ILnStatConfig.h
 * @brief Native Wrapper for Managed type ILnStatConfig.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _ILN_STAT_CONFIG_H
#define _ILN_STAT_CONFIG_H
namespace LarsonDavis
{
	namespace Native
	{
		struct LDAPI ValueTuple_float_float;
		struct LDAPI SLnTable_t;
		struct LDAPI ValueTuple_bool_SLnTable_t;

		class LDAPI ILnStatConfig
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			ILnStatConfig(const ILnStatConfig& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~ILnStatConfig(void);
			virtual float CalculateUpperdB(int32_t numBins, bool hasOverUnder = true);
			virtual std::shared_ptr<ValueTuple_float_float> GetRange(void);
			virtual StringWrapper GetFormattedLevelWithinRange(float level);
			virtual std::shared_ptr<ValueTuple_bool_SLnTable_t> UpdateLnTableBin(std::shared_ptr<SLnTable_t> lnTable, int32_t bin);
			virtual int32_t BinsPerdB(void);
			virtual void BinsPerdB(int32_t value);
			virtual float BinResolutiondB(void);
			virtual void BinResolutiondB(float value);
			virtual float LowerdB(void);
			virtual void LowerdB(float value);
			virtual float UpperdB(void);
			virtual void UpperdB(float value);
			virtual float SpandB(void);
			virtual void SpandB(float value);
			virtual int32_t NumStatBins(void);
			virtual void NumStatBins(int32_t value);
			virtual int32_t NumLnStatBins(void);
			virtual void NumLnStatBins(int32_t value);
			virtual int32_t UnderBin(void);
			virtual void UnderBin(int32_t value);
			virtual int32_t OverBin(void);
			virtual void OverBin(int32_t value);
			virtual float MinPercent(void);
			virtual void MinPercent(float value);
			virtual float MaxPercent(void);
			virtual void MaxPercent(float value);
#ifdef MAKEDLL
		public: // This is for internal use
			ILnStatConfig(){};
			ILnStatConfig(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _ILN_STAT_CONFIG_H
