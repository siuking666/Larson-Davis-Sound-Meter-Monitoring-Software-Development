/**************************************************************************//**
 * @file ValueTuple_float_float.h
 * @brief Native Wrapper for Managed type ValueTuple<System::Single, System::Single>.
 * @version 1.1.0
 * @author Kevin Lawrence
 ******************************************************************************
 * @section License
 * <b> (C)Copyright 2024 Larson Davis, A PCB Piezotronics Div.</b>
 * <b> Confidential </b>
 *
******************************************************************************/ 


#ifndef _VALUE_TUPLE_FLOAT_FLOAT_H
#define _VALUE_TUPLE_FLOAT_FLOAT_H
#include <ITuple.h>
namespace LarsonDavis
{
	namespace Native
	{
		class LDAPI ITuple;

		struct LDAPI ValueTuple_float_float : public virtual ITuple
		{
		public: // This section is the available interface
			// This does not create a copy of the underlying object but simply clones the wrapper.
			ValueTuple_float_float(const ValueTuple_float_float& other);
			//Will destry the wrapper and remove the managed referece so GC can collect the object once all wrappers are destroyed.
			virtual ~ValueTuple_float_float(void);
			ValueTuple_float_float(void);
			int32_t CompareTo(std::shared_ptr<ValueTuple_float_float> other);
			ValueTuple_float_float(float item1, float item2);
			float Item1(void);
			void Item1(float value);
			float Item2(void);
			void Item2(float value);
#ifdef MAKEDLL
		public: // This is for internal use
			ValueTuple_float_float(nullptr_t none);
			virtual void* GetId() const { return (void*)this; }
#endif // MAKEDLL
		};
	}
}
#endif // _VALUE_TUPLE_FLOAT_FLOAT_H
