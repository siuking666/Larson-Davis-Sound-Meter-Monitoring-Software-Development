#pragma once

void ReadSlmRecord(std::shared_ptr<LarsonDavis::Native::CTranslationResult>& result);
void ReadSpartanRecord(std::shared_ptr<LarsonDavis::Native::CTranslationResult>& result);
