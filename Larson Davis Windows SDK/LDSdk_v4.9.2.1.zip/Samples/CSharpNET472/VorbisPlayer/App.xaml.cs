﻿using System.Windows;

namespace LarsonDavis.Sdk.VorbisPlayer
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}
}
