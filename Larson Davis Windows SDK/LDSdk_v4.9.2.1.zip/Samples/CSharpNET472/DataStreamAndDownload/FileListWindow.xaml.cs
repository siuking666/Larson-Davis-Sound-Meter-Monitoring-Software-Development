﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using Microsoft.Win32;
using Newtonsoft.Json.Linq;

namespace LarsonDavis.Sdk.DataStreamAndDownload
{

	/// <summary>
	/// Enum LDBinHeader
	/// </summary>
	public enum LDBinHeader : int
	{
		/// <summary>
		/// 'LD'
		/// </summary>
		Ld = (0x00004C44),
		/// <summary>
		/// 'BIN'
		/// </summary>
		Bin = (0x0042494E),
		/// <summary>
		/// The version
		/// </summary>
		Ver = (0x00000001)
	}

	/// <summary>
	/// Interaction logic for FileListWindow.xaml
	/// </summary>
	public partial class FileListWindow : Window
	{
		private HttpClient _client;
		bool _keepGetting = true;

		public FileListWindow()
		{
			InitializeComponent();
			Loaded += FileListWindow_Loaded;
		}

		public FileListWindow(HttpClient client)
			: this()
		{
			_client = client;
		}

		private void FileListWindow_Loaded(object sender, RoutedEventArgs e)
		{
			var _ = GetFileList();
		}

		protected override void OnClosed(EventArgs e)
		{
			_keepGetting = false;
			base.OnClosed(e);
		}

		private async Task GetFileList()
		{
			if (_client != null)
			{
				int start = 0;
				do
				{
					try
					{
						var files = await _client.GetDataFileList(start, 500);
						var dataFiles = (JArray)files["DataFiles"];
						if (dataFiles.Count > 0)
						{
							DateTime epoch = new DateTime(1970, 1, 1);
							foreach (var file in dataFiles)
							{
								string startTime = epoch.AddSeconds((int)file["startTime"]).ToLocalTime().ToString();
								FileList.Items.Add(new FileListItem { Index = (int)file["index"], Name = (string)file["name"], Location = (int)file["location"], Start = startTime, Size = (uint)file["size"] });
							}
						}
						_keepGetting = dataFiles.Count == 500;
					}
					catch
					{

					}
				}
				while (_keepGetting);
			}
		}

		private void FileList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			var file = (FileListItem)FileList.SelectedItem;
			Stream saveLocation;
			SaveFileDialog sfd = new SaveFileDialog();
			sfd.FileName = Path.GetFileNameWithoutExtension(file.Name) + ".ldbin";
			var res = sfd.ShowDialog();
			if (res == true)
			{
				saveLocation = sfd.OpenFile();
				Task.Run(() => DownloadFile(file, saveLocation));
			}
		}

		private async Task DownloadFile(FileListItem file, Stream saveStream)
		{
			const int HEADER_SIZE = 20;
			Dispatcher.BeginInvoke((Action)(() =>
			{
				file.Downloaded = 0.0f;
			}));

			Stream stream = null;


			try
			{
				if (file.Size <= uint.MaxValue)
				{
					// A downloaded file needs the LDBin header prepended to it.
					saveStream.Write(BitConverter.GetBytes((int)LDBinHeader.Ld), 0, sizeof(int));
					saveStream.Write(BitConverter.GetBytes((int)LDBinHeader.Bin), 0, sizeof(int));
					saveStream.Write(BitConverter.GetBytes((int)LDBinHeader.Ver), 0, sizeof(int));
					saveStream.Write(BitConverter.GetBytes(1), 0, sizeof(int));

					byte[] cntBytes = BitConverter.GetBytes(file.Size);
					saveStream.Write(cntBytes, 0, sizeof(int));

					int counter = 29;
					bool done = false;
					int pos = 0;
					byte[] buffer = new byte[10240];
					while (!done)
					{
						try
						{
							if (null == stream)
							{
								stream = await _client.GetDownloadStream(file.Index, file.Size);
							}

							if (stream != null)
							{
								int read = stream.Read(buffer, 0, (int)Math.Min(buffer.Length, file.Size - pos));
								if (read > 0 && pos + read > 200)
								{
									counter = 29;
									pos += read;
									saveStream.Write(buffer, 0, read);

									await Dispatcher.BeginInvoke((Action)(() =>
									{
										file.Downloaded = file.Size / (float)saveStream.Length;
									}));
								}
								else
								{
									counter--;
								}
							}
						}
						catch (Exception ex)
						{
							counter--;
						}

						if (saveStream.Length == file.Size + HEADER_SIZE)
						{
							done = true;
						}

						if (counter % 5 == 0)
						{
							stream?.Close();
							stream = null;
						}

						if (counter <= 0)
						{
							done = true;
						}
					}
				}
			}
			catch (Exception ex)
			{

			}
			finally
			{
				stream?.Close();
				saveStream.Flush();
				saveStream.Close();
			}
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			Close();
		}
	}

	public class FileListItem : INotifyPropertyChanged
	{
		private float _downloaded = 0;
		public int Index { get; set; }
		public string Name { get; set; }
		public int Location { get; set; }
		public string Start { get; set; }
		public uint Size { get; set; }
		public float Downloaded
		{
			get { return _downloaded; }
			set
			{
				_downloaded = value;
				RaisePropertyChanged();
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		private void RaisePropertyChanged([CallerMemberName]string prop = null)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
		}
	}

	public class FileSizeConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			string result = null;
			string[] units = new[] { "B", "KB", "MB", "GB" };
			int unitIndex = 0;
			if (value is uint)
			{
				double size = (uint)value;

				while (size > 1024)
				{
					unitIndex++;
					size /= 1024;
				}

				result = $"{size: #.##} {units[unitIndex]}";
			}
			return result ?? value;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
