﻿namespace LarsonDavis.Sdk.AuthenticationExample
{
	public class UserItem
	{
		public string Username { get; set; }
		public string Email { get; set; }

	}
}
